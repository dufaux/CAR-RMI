/**
 * Contains principal interfaces of the project.
 */
package rmi;