/**
 * Contains interfaces and implementations of site in a tree network
 */
package rmi.tree;