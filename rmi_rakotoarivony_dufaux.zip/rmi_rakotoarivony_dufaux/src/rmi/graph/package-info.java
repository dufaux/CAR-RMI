/**
 * Contains interfaces and implementations of site in a graph network
 */
package rmi.graph;