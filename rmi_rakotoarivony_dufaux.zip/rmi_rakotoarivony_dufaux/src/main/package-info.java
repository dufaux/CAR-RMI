/**
 * Contains the executables of the application
 */
package main;